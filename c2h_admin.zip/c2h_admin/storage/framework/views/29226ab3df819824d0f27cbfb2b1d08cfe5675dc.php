<html>
	<body>
		<pre>
	Privacy policy 

	Kureup ( collectively "we", "us" and/or "our") respects your privacy and protecting your personal data.

	This privacy policy describes how we handle the personal information which we collect through our app.

	What personal information we collect:

	* Identity data such as Name and images 
	* Contact information including email
	* Address 
	* Other information relevant to customer surveys and/or offers.

	What we do with your personal information:

	In particular for the following reasons:
	* Record keeping 
	* To view your order History. 
	* we may use the information to improve our service. 

	How we use your personal information:

	We use this information to closely monitor which features of the service are used most.

	Kureup never sell your personal information like phone number, address or email  with any third party.
	We may change the terms from time to time  and it is the current version  which will apply to each order when you place it. We will notify you of changes to the Terms by email. 

	Contact us:

	If there are any questions regarding our privacy policy you may contact us at <strong>mrpharmanapp@gmail.com</strong>
		</pre>
	</body>
</html><?php /**PATH /home/demoproducts.in/c2h_v2_dev/resources/views/privacy_policy.blade.php ENDPATH**/ ?>