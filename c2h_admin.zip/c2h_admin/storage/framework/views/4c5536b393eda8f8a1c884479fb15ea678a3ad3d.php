<div class="container" id="printableArea">
      <div class="row">
        <div class="col-md-6">
            <span class="pull-left">
                <h2>INVOICE</h2>
            </span>
        </div>
        <div class="col-md-6"><span class="pull-right">
            <h2><?php echo e($lab_name, false); ?></h2>
            <h6><?php echo e($lab_address, false); ?></h6>
        </span></div>
      </div>
    <hr>
    <div class="col-md-6">
        <div class="table-responsive">          
          <table class="table">
            <tbody>
              <tr>
                <th>Order Id</th>
                <td><?php echo e($order_id, false); ?></td>
              </tr>
              <tr>
                <th>Customer Name</th>
                <td><?php echo e($customer_name, false); ?></td>
              </tr>
              <tr>
                <th>Customer Phone Number</th>
                <td><?php echo e($customer_phone_number, false); ?></td>
              </tr>
              <tr>
                <th>Customer Address</th>
                <td><?php echo e($address, false); ?></td>
              </tr>
              <tr>
                <th>Laboratory Name</th>
                <td><?php echo e($lab_name, false); ?></td>
              </tr>
              <tr>
                <th>Laboratory Phone Number</th>
                <td><?php echo e($lab_phone_number, false); ?></td>
              </tr>
              <tr>
                <th>Collective Person</th>
                <td><?php echo e($collective_person, false); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
    </div>
    <div class="col-md-6">
        <table class="table">
            <tbody>
              <tr>
                <th>Payment Mode</th>
                <td><?php echo e($payment_mode, false); ?></td>
              </tr>
              <tr>
                <th>Sub Total</th>
                <td><?php echo e($sub_total, false); ?></td>
              </tr>
              <tr>
                <th>Discount</th>
                <td><?php echo e($discount, false); ?></td>
              </tr>
              <tr>
                <th>Tax</th>
                <td><?php echo e($tax, false); ?></td>
              </tr>
              <tr>
                <th>Total</th>
                <td><?php echo e($total, false); ?></td>
              </tr>
              <tr>
                <th>Status</th>
                <td><?php echo e($status, false); ?></td>
              </tr>
            </tbody>
          </table>
    </div>
    <div class="col-lg-12">
        <h3>Items</h3>
        <table class="table table-hover">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Package</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
            <?php $i=1; ?>
            <?php $__currentLoopData = $order_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($i, false); ?></td>
                <td><?php echo e($value->package_name, false); ?></td>
                <td><?php echo e($value->price, false); ?></td>
              </tr>
              <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<script>
    function printDiv(divName) {
         var printContents = document.getElementById(divName).innerHTML;
         var originalContents = document.body.innerHTML;
    
         document.body.innerHTML = printContents;
    
         window.print();
    
         document.body.innerHTML = originalContents;
    }
</script>
<div class="col-md-12">
    <span class="pull-right">
        <button class="btn btn-default" onclick="printDiv('printableArea')" >Print</button>
    </span>
</div>
<?php /**PATH /home/demoproducts.in/c2h_v2_dev/resources/views/admin/view_lab_orders.blade.php ENDPATH**/ ?>