<div class="container">
    <div class="col-lg-8">
        <div class="table-responsive">          
          <table class="table">
            <tbody>
              <tr>
                <th>Patient Name</th>
                <td><?php echo e($patient_details->customer_name, false); ?></td>
              </tr>
              <tr>
                <th>Gender</th>
                <?php if($patient_details->gender == 1): ?>
                <td>Male</td>
                <?php elseif($patient_details->gender == 2): ?>
                <td>Female</td>
                <?php else: ?>
                <td>---</td>
                <?php endif; ?>
              </tr>
              <tr>
                <th>Blood Group</th>
                <?php if($patient_details->blood_group): ?>
                <td><?php echo e($patient_details->blood_group, false); ?></td>
                <?php else: ?>
                <td>---</td>
                <?php endif; ?>
              </tr>
              <tr>
                <th>Pre Existing Disease</th>
                <?php if($patient_details->pre_existing_desease): ?>
                <td><?php echo e($patient_details->pre_existing_desease, false); ?></td>
                <?php else: ?>
                <td>---</td>
                <?php endif; ?>
              </tr>
            </tbody>
          </table>
        </div>
    </div>
    <div class="col-lg-12">
        <h3>Items</h3>
        <table class="table table-hover">
            <thead>
              <tr>
                <th>S.No</th>
                <th>Doctor Name</th>
                <th>Title</th>
                <th>Description</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
            <?php $i=1; ?>
            <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($i, false); ?></td>
                <td>Dr.<?php echo e($value->doctor_name.'-'.$value->hospital_name, false); ?></td>
                <td><?php echo e($value->title, false); ?></td>
                <td><?php echo e($value->description, false); ?></td>
                <td><?php echo e($value->start_time, false); ?></td>
              </tr>
              <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH /home/demoproducts.in/c2h_v2_dev/resources/views/admin/patient_histories.blade.php ENDPATH**/ ?>