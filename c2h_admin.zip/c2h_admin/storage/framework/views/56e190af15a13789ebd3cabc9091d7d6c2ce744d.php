 
<head>

    <style>
        div.border { 
          border: 2px solid;
      }
      .center{
        text-align:center;
    }
    .column {
      float: left;
      width: 50%;
  }

  .right{
    float:right;text-align: right;
}

.padding{
    padding:0px 10px;
}
/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
.font-p{
    font-size: 23px;
}
table, th, td {
  /*border: 1px solid black;*/
  border-collapse: collapse;
  font-size: 23px;
}
th, td {
  padding: 5px;
  text-align: left;    
}

.text-black{
    color:black;
}

.theme_clr{
    color:#00bcd4;
}
</style>

</head>
<body >
    <div class="row" style="width:70%; margin:auto!important;">
        <div class="row" style="background:#00bcd4!important; padding:0 7% 0 7%">
            <div style="float:left; width:90%;">
                <h1 class="left text-black"><?php echo e($data[0]['header']->doctor_name, false); ?> <?php echo e($data[0]['header']->doctor_qualification, false); ?></h1>
                <h2 class="left text-black"><?php echo e($data[0]['header']->doctor_specialist, false); ?></h2>
                <h2 class="left text-black">Experience - <?php echo e($data[0]['header']->doctor_experience, false); ?>years</h2>
            </div>
            <div style="float:right; width:10%">
                <img src="<?php echo e(env('APP_URL'), false); ?>/uploads/<?php echo e($data[0]['header']->doctor_image, false); ?>"  alt="doctor_img" width="150" height="150">
            </div>
        </div>

        <div class="row" style="padding:0 7% 0 7%">
            <hr style="margin-top:7%;padding:0 7% 0 7%">

            <div style="float:left; width:50%; ">
                <h3 class="left" >Booking start time : <?php echo e($data[0]['header']->booking_start_time, false); ?></h3>
                <h3 class="left">Booking end time : <?php echo e($data[0]['header']->booking_end_time, false); ?></h3>
            </div>
            <div style="float:right; width:50%;">
                <h3 style="text-align: right">Prescription No.: <?php echo e($data[0]['header']->prescription_id, false); ?> </h3>
            </div>
            <div style="clear:both"></div>
             <hr style="padding:0 7% 0 7%">
        </div>
         <div class="row" style="padding:0 7% 0 7%; margin-top:4%">
                <img src="<?php echo e(env('APP_URL'), false); ?>/uploads/<?php echo e($data[0]['header']->doctor_image, false); ?>"  alt="prescription-image" width="150" height="150">
        </div>

         <div class="row" style="padding:0 7% 0 7%; margin-top:7%">
            <div style="float:left; width:20%;">
                <h3 class="left theme_clr">Mr/Mrs </h3>
                <h3 class="left theme_clr">Address</h3>
                <h3 class="left theme_clr">Contact number</h3>
            </div>
            <div style="float:left; width:80%;">
                <h3 class="left"><?php echo e($data[0]['header']->customer_name, false); ?> </h3>
                <h3 class="left"><?php echo e($data[0]['header']->customer_address, false); ?></h3>
                <h3 class="left"><?php echo e($data[0]['header']->customer_phone_number, false); ?></h3>
            </div>
        </div>
        <div class="row" style="background:#00bcd4!important; padding:0 7% 0 7%;margin-top:7%">
            <div style="float:left; width:50%;">
                <h3 class="left text-black">Contact number : <?php echo e($data[0]['header']->doctor_phone_number, false); ?></h3>
            </div>
            <div style="float:right; width:50%">
                <h3 class="text-black" style="text-align:right ">Email Id: <?php echo e($data[0]['header']->doctor_email, false); ?></h3>
            </div>
        </div>
</div>
</body>
<?php /**PATH C:\xampp\htdocs\Wecare\resources\views/admin/bookingpdf.blade.php ENDPATH**/ ?>